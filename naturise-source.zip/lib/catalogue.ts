export const categories=['Vitamines','Compléments','Aromathérapie','Nutrition sportive','Soins'];
export type Product={id:string;name:string;category:string;price:number;size:string;image:string;description:string;stock:number;active:number;demo:number;featured:number};
export const seed:Product[]=[
 ['vitamine-c','Vitamine C 1000',0,8500,'60 gélules','vitamins',24,1],
 ['magnesium','Magnésium marin',1,12500,'60 gélules','vitamins',18,1],
 ['lavande','Huile essentielle de lavande',2,6500,'10 ml','oil',20,1],
 ['proteine','Protéine végétale · Vanille',3,24500,'750 g','protein',12,1],
 ['serum','Sérum visage éclat',4,15500,'30 ml','oil',16,0],
 ['vitamine-d','Vitamine D3',0,7500,'60 capsules','vitamins',32,0],
 ['omega','Oméga 3',1,14000,'60 capsules','vitamins',10,0],
 ['menthe','Huile essentielle de menthe',2,5500,'10 ml','oil',15,0],
 ['creatine','Créatine monohydrate',3,19500,'300 g','protein',8,0],
 ['huile','Huile de soin corps',4,9500,'100 ml','oil',0,0]
].map(([id,name,cat,price,size,img,stock,featured])=>({id:String(id),name:String(name),category:categories[Number(cat)],price:Number(price),size:String(size),image:`/images/${img}.png`,description:'Une référence de démonstration pour le catalogue Naturise. Le nom, le prix et le visuel sont illustratifs. Remplacez cette fiche par les caractéristiques de votre produit réel avant sa commercialisation.',stock:Number(stock),active:1,demo:1,featured:Number(featured)}));
export const money=(n:number)=>new Intl.NumberFormat('fr-SN').format(n)+' FCFA';
