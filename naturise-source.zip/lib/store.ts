import {env} from 'cloudflare:workers';
import {seed,type Product} from './catalogue';
export function db(){if(!env.DB)throw Error('Base indisponible');return env.DB;}
export async function initCatalogue(){
 const d=db();if(await d.prepare("SELECT value FROM settings WHERE key='catalogue_seed'").first())return;
 const statements=seed.map(p=>d.prepare("INSERT OR IGNORE INTO products (id,name,category,price,size,image,description,stock,active,demo,featured) SELECT ?,?,?,?,?,?,?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM settings WHERE key='catalogue_seed')").bind(p.id,p.name,p.category,p.price,p.size,p.image,p.description,p.stock,p.active,p.demo,p.featured));
 statements.push(d.prepare("INSERT OR IGNORE INTO settings (key,value) VALUES ('catalogue_seed','1')"));await d.batch(statements);
}
export async function catalogue(all=false){await initCatalogue();return (await db().prepare('SELECT * FROM products'+(all?'':' WHERE active=1')+' ORDER BY featured DESC, rowid').all<Product>()).results;}

