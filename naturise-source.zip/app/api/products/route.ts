import {catalogue} from '@/lib/store';import {reply} from '@/lib/admin-auth';
export async function GET(){try{return reply({products:await catalogue()})}catch(e){console.error(e);return reply({error:'Catalogue momentanément indisponible. Réessayez.'},503)}}

