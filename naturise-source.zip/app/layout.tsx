import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Naturise — La boutique du bien-être",
  description: "Vitamines, compléments, aromathérapie, nutrition sportive et soins à Dakar.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body className="antialiased">{children}</body>
    </html>
  );
}
