import {requireChatGPTUser} from '@/app/chatgpt-auth';import {isAdmin} from '@/lib/admin-auth';import Admin from './panel';
export const dynamic='force-dynamic';
export default async function Page(){await requireChatGPTUser('/admin');if(!await isAdmin())return <main style={{padding:60}}><h1>Accès réservé</h1><p>Ce compte n’est pas administrateur de Naturise.</p><a href="/">Retour à la boutique</a></main>;return <Admin/>}

